import greenfoot.*; 
/**
 * Write a description of class NameScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SecretScreen extends Screen
{
    // instance variables - replace the example below with your own
   private IScreenHandler nextScreen = null;
   private SortingWorld world;
   
   
   public SecretScreen(SortingWorld world)
   {
       super(world);
       this.world = world;
       APIHelper.setScores(world.getUser(), world.getPlayerNumber(), 100000, world.getRoomID());
   }
   
   public void setNextScreen(IScreenHandler nextScreen)
   {
       this.nextScreen=nextScreen;
   }
   
   public void showScreen()
   {
       //write code for name screen
       world.setBackground(new GreenfootImage("Story1.png"));
       world.addObject(new secret_next(this.world), 910,520);
    
       
   }
}

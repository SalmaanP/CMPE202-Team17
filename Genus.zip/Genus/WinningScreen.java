import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class WinningScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WinningScreen extends Screen
{
    private IScreenHandler nextScreen = null;
    private SortingWorld world;
    public WinningScreen(SortingWorld world)
    {
        super(world);
    }

   public void setNextScreen(IScreenHandler nextScreen)
   {

   }
   
   public void showScreen()
   {

   }
   
   public void removeScreen(){

    }  
}

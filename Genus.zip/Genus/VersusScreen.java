import greenfoot.*;
import org.json.*;
/**
 * Write a description of class VersusScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class VersusScreen extends Screen 
{
    SortingWorld world = (SortingWorld) this.sortingWorld;
    // instance variables - replace the example below with your own
    private int x;
    private IScreenHandler mainScreen = new MainScreen(world);

    /**
     * Constructor for objects of class VersusScreen
     */
    public VersusScreen(SortingWorld world)
    {
        super(world);
    }

   public void setNextScreen(IScreenHandler nextScreen)
   {
       world.setScreen(mainScreen);
       removeScreen();
       world.screen.showScreen();
   }
   
   public void showScreen()
   {      
       this.sortingWorld.setBackground(new GreenfootImage("versus.png"));
       this.sortingWorld.addObject(new Versus(this.sortingWorld), 500, 275);
   }
   
   
   
   public void removeScreen(){
       world.removeObjects(world.getObjects(Versus.class));
       
    }
    
}
